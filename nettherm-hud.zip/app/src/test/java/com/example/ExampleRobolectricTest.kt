package com.example

import android.content.Context
import android.net.wifi.ScanResult
import android.view.View
import androidx.test.core.app.ApplicationProvider
import com.example.model.OverlayConfig
import com.example.model.TelemetryFormatter
import com.example.model.TelemetrySnapshot
import com.example.model.TempUnit
import com.example.overlay.HudOverlayView
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NetTherm HUD", appName)
  }

  @Test
  fun `formatSpeedStacked formats KB and MB cleanly`() {
    assertEquals("0.00" to "KB/S", TelemetryFormatter.formatSpeedStacked(0L))
    assertEquals("6.00" to "KB/S", TelemetryFormatter.formatSpeedStacked(6144L))
    assertEquals("1.50" to "MB/S", TelemetryFormatter.formatSpeedStacked(1572864L))
  }

  @Test
  fun `formatTemperature converts celsius and fahrenheit accurately`() {
    assertEquals("34.5°C", TelemetryFormatter.formatTemperature(34.5f, TempUnit.CELSIUS))
    assertEquals("94.1°F", TelemetryFormatter.formatTemperature(34.5f, TempUnit.FAHRENHEIT))
  }

  @Test
  fun `resolveWifiVersion identifies Wi-Fi 5, 6, 6E, and 7`() {
    assertEquals(
      "5",
      TelemetryFormatter.resolveWifiVersion(ScanResult.WIFI_STANDARD_11AC, 5180, 866, true).first,
    )
    assertEquals(
      "6",
      TelemetryFormatter.resolveWifiVersion(ScanResult.WIFI_STANDARD_11AX, 5240, 1200, true).first,
    )
    assertEquals(
      "6E",
      TelemetryFormatter.resolveWifiVersion(ScanResult.WIFI_STANDARD_11AX, 6115, 2400, true).first,
    )
    assertEquals(
      "7",
      TelemetryFormatter.resolveWifiVersion(ScanResult.WIFI_STANDARD_11BE, 6115, 4800, true).first,
    )
    assertEquals(
      "–",
      TelemetryFormatter.resolveWifiVersion(ScanResult.WIFI_STANDARD_11AC, 5180, 866, false).first,
    )
  }

  @Test
  fun `HudOverlayView measures non-zero compact bounds`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val view = HudOverlayView(context)
    view.updateState(
      TelemetrySnapshot(
        isWifiConnected = true,
        wifiSignalLevel = 3,
        wifiVersionLabel = "5",
        totalBytesPerSec = 6144L,
        rxBytesPerSec = 5000L,
        txBytesPerSec = 1144L,
        batteryPercent = 59,
        batteryTempCelsius = 34.5f,
      ),
      OverlayConfig(),
    )
    val widthSpec = View.MeasureSpec.makeMeasureSpec(500, View.MeasureSpec.AT_MOST)
    val heightSpec = View.MeasureSpec.makeMeasureSpec(500, View.MeasureSpec.AT_MOST)
    view.measure(widthSpec, heightSpec)

    assertTrue(view.measuredWidth > 0)
    assertTrue(view.measuredHeight > 0)
  }
}
