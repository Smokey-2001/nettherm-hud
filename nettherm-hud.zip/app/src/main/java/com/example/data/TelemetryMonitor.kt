package com.example.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.example.model.RefreshInterval
import com.example.model.TelemetryFormatter
import com.example.model.TelemetrySnapshot
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

class TelemetryMonitor(context: Context) {

  private val appContext = context.applicationContext
  private val connectivityManager =
    appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
  private val wifiManager =
    appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
  private val powerManager =
    appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager

  fun observeTelemetry(
    refreshIntervalFlow: Flow<RefreshInterval> = flowOf(RefreshInterval.BALANCED_2S),
    pauseOnScreenOffFlow: Flow<Boolean> = flowOf(true),
  ): Flow<TelemetrySnapshot> = channelFlow {
    val batteryFlow = MutableStateFlow(readBatteryOnce())
    val wifiFlow = MutableStateFlow(readCurrentWifiInfo(null))
    val speedFlow = MutableStateFlow(SpeedSample(0L, 0L, 0L))
    val screenInteractiveFlow = MutableStateFlow(powerManager?.isInteractive ?: true)

    val batteryReceiver =
      object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          if (intent != null) {
            batteryFlow.value = parseBatteryIntent(intent)
          }
        }
      }

    val screenReceiver =
      object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
          when (intent?.action) {
            Intent.ACTION_SCREEN_OFF -> screenInteractiveFlow.value = false
            Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT ->
              screenInteractiveFlow.value = true
          }
        }
      }

    ContextCompat.registerReceiver(
      appContext,
      batteryReceiver,
      IntentFilter(Intent.ACTION_BATTERY_CHANGED),
      ContextCompat.RECEIVER_NOT_EXPORTED,
    )

    val screenFilter =
      IntentFilter().apply {
        addAction(Intent.ACTION_SCREEN_OFF)
        addAction(Intent.ACTION_SCREEN_ON)
        addAction(Intent.ACTION_USER_PRESENT)
      }
    ContextCompat.registerReceiver(
      appContext,
      screenReceiver,
      screenFilter,
      ContextCompat.RECEIVER_NOT_EXPORTED,
    )

    val networkCallback =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        object : ConnectivityManager.NetworkCallback(FLAG_INCLUDE_LOCATION_INFO) {
          override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities,
          ) {
            wifiFlow.value = readCurrentWifiInfo(networkCapabilities)
          }

          override fun onLost(network: Network) {
            wifiFlow.value = readCurrentWifiInfo(null)
          }
        }
      } else {
        object : ConnectivityManager.NetworkCallback() {
          override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities,
          ) {
            wifiFlow.value = readCurrentWifiInfo(networkCapabilities)
          }

          override fun onLost(network: Network) {
            wifiFlow.value = readCurrentWifiInfo(null)
          }
        }
      }

    val registeredCallback =
      runCatching {
          connectivityManager?.registerDefaultNetworkCallback(networkCallback)
          true
        }
        .getOrDefault(false)

    // Power-aware polling: suspends completely when screen is off to save battery
    val pollerJob = launch {
      combine(refreshIntervalFlow, pauseOnScreenOffFlow, screenInteractiveFlow) {
          interval,
          pauseOnOff,
          isInteractive ->
          val shouldPoll = !pauseOnOff || isInteractive
          shouldPoll to interval.intervalMs
        }
        .distinctUntilChanged()
        .collectLatest { (shouldPoll, intervalMs) ->
          if (!shouldPoll) {
            return@collectLatest
          }

          var prevRx = TrafficStats.getTotalRxBytes()
          var prevTx = TrafficStats.getTotalTxBytes()
          var prevTimeMs = SystemClock.elapsedRealtime()

          // Immediate refresh when waking back up
          val wakeCaps =
            connectivityManager?.activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
          wifiFlow.value = readCurrentWifiInfo(wakeCaps)
          batteryFlow.value = readBatteryOnce()

          while (true) {
            delay(intervalMs)
            val nowMs = SystemClock.elapsedRealtime()
            val elapsedMs = (nowMs - prevTimeMs).coerceAtLeast(1L)

            val currentRx = TrafficStats.getTotalRxBytes()
            val currentTx = TrafficStats.getTotalTxBytes()

            val rxRate =
              if (
                prevRx != TrafficStats.UNSUPPORTED.toLong() &&
                  currentRx != TrafficStats.UNSUPPORTED.toLong()
              ) {
                val deltaRx = (currentRx - prevRx).coerceAtLeast(0L)
                (deltaRx * 1000L) / elapsedMs
              } else {
                0L
              }

            val txRate =
              if (
                prevTx != TrafficStats.UNSUPPORTED.toLong() &&
                  currentTx != TrafficStats.UNSUPPORTED.toLong()
              ) {
                val deltaTx = (currentTx - prevTx).coerceAtLeast(0L)
                (deltaTx * 1000L) / elapsedMs
              } else {
                0L
              }

            prevRx = currentRx
            prevTx = currentTx
            prevTimeMs = nowMs

            speedFlow.value = SpeedSample(rxRate, txRate, rxRate + txRate)

            val activeCaps =
              connectivityManager?.activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
            wifiFlow.value = readCurrentWifiInfo(activeCaps)
          }
        }
    }

    val collectorJob = launch {
      combine(batteryFlow, wifiFlow, speedFlow) { battery, wifi, speed ->
          TelemetrySnapshot(
            isWifiConnected = wifi.isConnected,
            wifiSignalLevel = wifi.signalLevel,
            wifiRssiDbm = wifi.rssiDbm,
            wifiVersionLabel = wifi.versionLabel,
            wifiStandardDescription = wifi.standardDescription,
            wifiLinkSpeedMbps = wifi.linkSpeedMbps,
            wifiFrequencyMhz = wifi.frequencyMhz,
            rxBytesPerSec = speed.rxBytesPerSec,
            txBytesPerSec = speed.txBytesPerSec,
            totalBytesPerSec = speed.totalBytesPerSec,
            batteryPercent = battery.percent,
            batteryTempCelsius = battery.tempCelsius,
            batteryStatusLabel = battery.statusLabel,
            batteryVoltageMv = battery.voltageMv,
          )
        }
        .distinctUntilChanged()
        .collect { snapshot -> send(snapshot) }
    }

    try {
      collectorJob.join()
    } finally {
      pollerJob.cancel()
      runCatching { appContext.unregisterReceiver(batteryReceiver) }
      runCatching { appContext.unregisterReceiver(screenReceiver) }
      if (registeredCallback) {
        runCatching { connectivityManager?.unregisterNetworkCallback(networkCallback) }
      }
    }
  }

  private fun readBatteryOnce(): BatterySample {
    val stickyIntent =
      ContextCompat.registerReceiver(
        appContext,
        null,
        IntentFilter(Intent.ACTION_BATTERY_CHANGED),
        ContextCompat.RECEIVER_NOT_EXPORTED,
      )
    return if (stickyIntent != null) parseBatteryIntent(stickyIntent) else BatterySample()
  }

  private fun parseBatteryIntent(intent: Intent): BatterySample {
    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
    val percent = if (level >= 0) ((level * 100f) / scale).roundToInt().coerceIn(0, 100) else 0
    val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
    val tempCelsius = tempTenths / 10f
    val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
    val statusLabel =
      when (status) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
        else -> "Unknown"
      }
    return BatterySample(
      percent = percent,
      tempCelsius = tempCelsius,
      statusLabel = statusLabel,
      voltageMv = voltageMv,
    )
  }

  @Suppress("DEPRECATION")
  private fun readCurrentWifiInfo(capabilities: NetworkCapabilities?): WifiSample {
    val caps =
      capabilities
        ?: connectivityManager?.activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
    val hasWifiTransport = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

    val infoFromCaps: WifiInfo? =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        caps?.transportInfo as? WifiInfo
      } else {
        null
      }

    val wifiInfo: WifiInfo? =
      infoFromCaps
        ?: runCatching { wifiManager?.connectionInfo }.getOrNull()

    val isConnected =
      hasWifiTransport || (wifiInfo != null && wifiInfo.networkId != -1 && wifiInfo.rssi > -127)

    if (!isConnected || wifiInfo == null) {
      return WifiSample(
        isConnected = false,
        signalLevel = 0,
        rssiDbm = -127,
        versionLabel = "–",
        standardDescription = "Wi-Fi Off / Disconnected",
        linkSpeedMbps = 0,
        frequencyMhz = 0,
      )
    }

    val rssi = wifiInfo.rssi
    val wm = wifiManager
    val level =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && wm != null) {
        val raw = runCatching { wm.calculateSignalLevel(rssi) }.getOrDefault(0)
        val max = runCatching { wm.maxSignalLevel }.getOrDefault(4).coerceAtLeast(1)
        TelemetryFormatter.normalizeSignalLevel(raw, max)
      } else {
        WifiManager.calculateSignalLevel(rssi, 5).coerceIn(0, 4)
      }

    val linkSpeed = wifiInfo.linkSpeed.coerceAtLeast(0)
    val frequency = wifiInfo.frequency.coerceAtLeast(0)
    val wifiStandard =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        wifiInfo.wifiStandard
      } else {
        null
      }

    val (versionLabel, standardDesc) =
      TelemetryFormatter.resolveWifiVersion(
        wifiStandard = wifiStandard,
        frequencyMhz = frequency,
        linkSpeedMbps = linkSpeed,
        isConnected = true,
      )

    return WifiSample(
      isConnected = true,
      signalLevel = level,
      rssiDbm = rssi,
      versionLabel = versionLabel,
      standardDescription = standardDesc,
      linkSpeedMbps = linkSpeed,
      frequencyMhz = frequency,
    )
  }

  private data class BatterySample(
    val percent: Int = 0,
    val tempCelsius: Float = 0f,
    val statusLabel: String = "Unknown",
    val voltageMv: Int = 0,
  )

  private data class WifiSample(
    val isConnected: Boolean,
    val signalLevel: Int,
    val rssiDbm: Int,
    val versionLabel: String,
    val standardDescription: String,
    val linkSpeedMbps: Int,
    val frequencyMhz: Int,
  )

  private data class SpeedSample(
    val rxBytesPerSec: Long,
    val txBytesPerSec: Long,
    val totalBytesPerSec: Long,
  )
}
