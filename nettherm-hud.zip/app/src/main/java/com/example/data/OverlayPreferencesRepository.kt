package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.EdgeSide
import com.example.model.InkPreset
import com.example.model.OverlayConfig
import com.example.model.RefreshInterval
import com.example.model.TempUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

private val Context.hudDataStore: DataStore<Preferences> by preferencesDataStore(name = "hud_preferences")

object OverlayServiceState {
  private val _isRunning = MutableStateFlow(false)
  val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

  private val _isPaused = MutableStateFlow(false)
  val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

  fun setRunning(running: Boolean) {
    _isRunning.value = running
    if (!running) _isPaused.value = false
  }

  fun setPaused(paused: Boolean) {
    _isPaused.value = paused
  }
}

class OverlayPreferencesRepository(private val context: Context) {

  private object Keys {
    val EDGE_SIDE = stringPreferencesKey("edge_side")
    val VERTICAL_POS = floatPreferencesKey("vertical_pos")
    val SEPARATE_LANDSCAPE_POS = booleanPreferencesKey("separate_landscape_pos")
    val LANDSCAPE_VERTICAL_POS = floatPreferencesKey("landscape_vertical_pos")
    val EDGE_MARGIN_DP = floatPreferencesKey("edge_margin_dp")
    val SCALE = floatPreferencesKey("scale")
    val CONTENT_ALPHA = floatPreferencesKey("content_alpha")
    val BACKDROP_ALPHA = floatPreferencesKey("backdrop_alpha")
    val SAFE_OPACITY_CAP = booleanPreferencesKey("safe_opacity_cap")
    val REFRESH_INTERVAL = stringPreferencesKey("refresh_interval")
    val PAUSE_ON_SCREEN_OFF = booleanPreferencesKey("pause_on_screen_off")
    val INK_PRESET = stringPreferencesKey("ink_preset")
    val TEMP_UNIT = stringPreferencesKey("temp_unit")
    val SHOW_SPEED = booleanPreferencesKey("show_speed")
    val SHOW_WIFI_SIGNAL = booleanPreferencesKey("show_wifi_signal")
    val SHOW_WIFI_VERSION = booleanPreferencesKey("show_wifi_version")
    val SHOW_BATTERY_PERCENT = booleanPreferencesKey("show_battery_percent")
    val SHOW_BATTERY_TEMP = booleanPreferencesKey("show_battery_temp")
  }

  val configFlow: Flow<OverlayConfig> = context.hudDataStore.data.map(::mapPrefsToConfig)

  suspend fun updateConfig(transform: (OverlayConfig) -> OverlayConfig) {
    context.hudDataStore.edit { prefs ->
      val current = mapPrefsToConfig(prefs)
      val next = transform(current)
      prefs[Keys.EDGE_SIDE] = next.edgeSide.name
      prefs[Keys.VERTICAL_POS] = next.verticalPositionPercent.coerceIn(0.03f, 0.88f)
      prefs[Keys.SEPARATE_LANDSCAPE_POS] = next.separateLandscapePos
      prefs[Keys.LANDSCAPE_VERTICAL_POS] = next.landscapeVerticalPercent.coerceIn(0.03f, 0.85f)
      prefs[Keys.EDGE_MARGIN_DP] = next.edgeMarginDp.coerceIn(0f, 24f)
      prefs[Keys.SCALE] = next.scale.coerceIn(0.75f, 1.50f)
      prefs[Keys.CONTENT_ALPHA] = next.contentAlpha.coerceIn(0.35f, 1.0f)
      prefs[Keys.BACKDROP_ALPHA] = next.backdropAlpha.coerceIn(0.0f, 0.65f)
      prefs[Keys.SAFE_OPACITY_CAP] = next.safeOpacityCap
      prefs[Keys.REFRESH_INTERVAL] = next.refreshInterval.name
      prefs[Keys.PAUSE_ON_SCREEN_OFF] = next.pauseOnScreenOff
      prefs[Keys.INK_PRESET] = next.inkPreset.name
      prefs[Keys.TEMP_UNIT] = next.tempUnit.name
      prefs[Keys.SHOW_SPEED] = next.showSpeed
      prefs[Keys.SHOW_WIFI_SIGNAL] = next.showWifiSignal
      prefs[Keys.SHOW_WIFI_VERSION] = next.showWifiVersion
      prefs[Keys.SHOW_BATTERY_PERCENT] = next.showBatteryPercent
      prefs[Keys.SHOW_BATTERY_TEMP] = next.showBatteryTemp
    }
  }

  private fun mapPrefsToConfig(prefs: Preferences): OverlayConfig {
    return OverlayConfig(
      edgeSide =
        prefs[Keys.EDGE_SIDE]?.let { runCatching { EdgeSide.valueOf(it) }.getOrNull() }
          ?: EdgeSide.RIGHT,
      verticalPositionPercent = (prefs[Keys.VERTICAL_POS] ?: 0.18f).coerceIn(0.03f, 0.88f),
      separateLandscapePos = prefs[Keys.SEPARATE_LANDSCAPE_POS] ?: true,
      landscapeVerticalPercent =
        (prefs[Keys.LANDSCAPE_VERTICAL_POS] ?: 0.10f).coerceIn(0.03f, 0.85f),
      edgeMarginDp = (prefs[Keys.EDGE_MARGIN_DP] ?: 6f).coerceIn(0f, 24f),
      scale = (prefs[Keys.SCALE] ?: 1.0f).coerceIn(0.75f, 1.50f),
      contentAlpha = (prefs[Keys.CONTENT_ALPHA] ?: 0.78f).coerceIn(0.35f, 1.0f),
      backdropAlpha = (prefs[Keys.BACKDROP_ALPHA] ?: 0.0f).coerceIn(0.0f, 0.65f),
      safeOpacityCap = prefs[Keys.SAFE_OPACITY_CAP] ?: true,
      refreshInterval =
        prefs[Keys.REFRESH_INTERVAL]?.let { runCatching { RefreshInterval.valueOf(it) }.getOrNull() }
          ?: RefreshInterval.BALANCED_2S,
      pauseOnScreenOff = prefs[Keys.PAUSE_ON_SCREEN_OFF] ?: true,
      inkPreset =
        prefs[Keys.INK_PRESET]?.let { runCatching { InkPreset.valueOf(it) }.getOrNull() }
          ?: InkPreset.CRISP_WHITE,
      tempUnit =
        prefs[Keys.TEMP_UNIT]?.let { runCatching { TempUnit.valueOf(it) }.getOrNull() }
          ?: TempUnit.CELSIUS,
      showSpeed = prefs[Keys.SHOW_SPEED] ?: true,
      showWifiSignal = prefs[Keys.SHOW_WIFI_SIGNAL] ?: true,
      showWifiVersion = prefs[Keys.SHOW_WIFI_VERSION] ?: true,
      showBatteryPercent = prefs[Keys.SHOW_BATTERY_PERCENT] ?: true,
      showBatteryTemp = prefs[Keys.SHOW_BATTERY_TEMP] ?: true,
    )
  }
}
