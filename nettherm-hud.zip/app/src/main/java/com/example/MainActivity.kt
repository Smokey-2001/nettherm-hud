package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainScreen
import com.example.ui.MainViewModel
import com.example.ui.theme.NetThermHudTheme

class MainActivity : ComponentActivity() {

  private val viewModel: MainViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val uiState by viewModel.uiState.collectAsStateWithLifecycle()
      val lifecycleOwner = LocalLifecycleOwner.current

      DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
          if (event == Lifecycle.Event.ON_RESUME) {
            viewModel.refreshOverlayPermission()
          }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
      }

      val notificationPermissionLauncher =
        rememberLauncherForActivityResult(
          contract = ActivityResultContracts.RequestPermission(),
        ) { _ ->
          // Overlay foreground service can start regardless of notification prompt result
          viewModel.setOverlayEnabled(true)
        }

      val overlayPermissionLauncher =
        rememberLauncherForActivityResult(
          contract = ActivityResultContracts.StartActivityForResult(),
        ) {
          viewModel.refreshOverlayPermission()
          if (Settings.canDrawOverlays(this@MainActivity)) {
            startOverlayWithNotificationCheck(notificationPermissionLauncher::launch)
          }
        }

      NetThermHudTheme {
        MainScreen(
          uiState = uiState,
          onToggleOverlay = { enable ->
            if (enable) {
              if (!Settings.canDrawOverlays(this@MainActivity)) {
                val intent =
                  Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"),
                  )
                overlayPermissionLauncher.launch(intent)
              } else {
                startOverlayWithNotificationCheck(notificationPermissionLauncher::launch)
              }
            } else {
              viewModel.setOverlayEnabled(false)
            }
          },
          onTogglePause = viewModel::setOverlayPaused,
          onRequestOverlayPermission = {
            val intent =
              Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"),
              )
            overlayPermissionLauncher.launch(intent)
          },
          onApplyPreset = viewModel::applyQuickPreset,
          onEdgeSideChange = viewModel::setEdgeSide,
          onVerticalPositionChange = viewModel::setVerticalPosition,
          onSeparateLandscapePosChange = viewModel::setSeparateLandscapePos,
          onLandscapeVerticalPositionChange = viewModel::setLandscapeVerticalPosition,
          onEdgeMarginChange = viewModel::setEdgeMarginDp,
          onScaleChange = viewModel::setScale,
          onContentAlphaChange = viewModel::setContentAlpha,
          onBackdropAlphaChange = viewModel::setBackdropAlpha,
          onSafeOpacityCapChange = viewModel::setSafeOpacityCap,
          onRefreshIntervalChange = viewModel::setRefreshInterval,
          onPauseOnScreenOffChange = viewModel::setPauseOnScreenOff,
          onInkPresetChange = viewModel::setInkPreset,
          onTempUnitChange = viewModel::setTempUnit,
          onShowSpeedChange = viewModel::setShowSpeed,
          onShowWifiSignalChange = viewModel::setShowWifiSignal,
          onShowWifiVersionChange = viewModel::setShowWifiVersion,
          onShowBatteryPercentChange = viewModel::setShowBatteryPercent,
          onShowBatteryTempChange = viewModel::setShowBatteryTemp,
          onResetDefaults = viewModel::resetDefaults,
        )
      }
    }
  }

  private fun startOverlayWithNotificationCheck(requestPermission: (String) -> Unit) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        requestPermission(Manifest.permission.POST_NOTIFICATIONS)
        return
      }
    }
    viewModel.setOverlayEnabled(true)
  }
}
