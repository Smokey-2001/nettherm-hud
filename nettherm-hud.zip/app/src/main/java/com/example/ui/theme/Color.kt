package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBackground = Color(0xFF0D1014)
val ObsidianSurface = Color(0xFF14181E)
val ObsidianSurfaceVariant = Color(0xFF1D232C)
val ObsidianOutline = Color(0xFF333C48)
val ObsidianOutlineVariant = Color(0xFF232A34)

val BrassPrimary = Color(0xFFE2C275)
val BrassOnPrimary = Color(0xFF1A1508)
val BrassContainer = Color(0xFF3A3018)
val BrassOnContainer = Color(0xFFF9E4AD)

val TelemetryMint = Color(0xFF6FD4BE)
val TelemetryOnMint = Color(0xFF06201A)
val TelemetryMintContainer = Color(0xFF163832)
val TelemetryOnMintContainer = Color(0xFFA9F4E3)

val SkyTertiary = Color(0xFF8BB8FF)
val WarmAmber = Color(0xFFFFCA6B)
val ThermalCoral = Color(0xFFFF7D7D)

val IvoryText = Color(0xFFF2EDE2)
val MutedSlateText = Color(0xFFA5AEBA)

// Light palette (Warm Editorial Paper)
val PaperBackground = Color(0xFFF6F2E9)
val PaperSurface = Color(0xFFFFFCF5)
val PaperSurfaceVariant = Color(0xFFE9E2D4)
val PaperOutline = Color(0xFFB5AC9B)
val PaperOutlineVariant = Color(0xFFDBD4C5)

val LightBrassPrimary = Color(0xFF7D5E18)
val LightBrassContainer = Color(0xFFF2E2BA)
val LightBrassOnContainer = Color(0xFF2B1F03)

val LightMintSecondary = Color(0xFF166859)
val LightMintContainer = Color(0xFFCAECE4)
val LightMintOnContainer = Color(0xFF062821)

val InkText = Color(0xFF181B20)
val MutedInkText = Color(0xFF565D68)
