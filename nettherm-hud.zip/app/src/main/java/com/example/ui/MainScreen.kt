package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.PauseCircle
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.ScreenRotation
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.EdgeSide
import com.example.model.InkPreset
import com.example.model.OverlayConfig
import com.example.model.RefreshInterval
import com.example.model.TelemetryFormatter
import com.example.model.TelemetrySnapshot
import com.example.model.TempUnit
import com.example.overlay.HudOverlayView
import com.example.ui.theme.ThermalCoral
import com.example.ui.theme.WarmAmber
import java.util.Locale
import kotlin.math.roundToInt

private enum class PreviewBackdrop(val label: String) {
  DARK_GAME("Dark Arena"),
  LIGHT_FEED("Light App"),
  TWILIGHT("Twilight"),
}

private enum class PreviewOrientation(val label: String) {
  PORTRAIT("Portrait"),
  LANDSCAPE("Landscape"),
}

@Composable
fun MainScreen(
  uiState: MainUiState,
  onToggleOverlay: (Boolean) -> Unit,
  onTogglePause: (Boolean) -> Unit,
  onRequestOverlayPermission: () -> Unit,
  onApplyPreset: (HudPreset) -> Unit,
  onEdgeSideChange: (EdgeSide) -> Unit,
  onVerticalPositionChange: (Float) -> Unit,
  onSeparateLandscapePosChange: (Boolean) -> Unit,
  onLandscapeVerticalPositionChange: (Float) -> Unit,
  onEdgeMarginChange: (Float) -> Unit,
  onScaleChange: (Float) -> Unit,
  onContentAlphaChange: (Float) -> Unit,
  onBackdropAlphaChange: (Float) -> Unit,
  onSafeOpacityCapChange: (Boolean) -> Unit,
  onRefreshIntervalChange: (RefreshInterval) -> Unit,
  onPauseOnScreenOffChange: (Boolean) -> Unit,
  onInkPresetChange: (InkPreset) -> Unit,
  onTempUnitChange: (TempUnit) -> Unit,
  onShowSpeedChange: (Boolean) -> Unit,
  onShowWifiSignalChange: (Boolean) -> Unit,
  onShowWifiVersionChange: (Boolean) -> Unit,
  onShowBatteryPercentChange: (Boolean) -> Unit,
  onShowBatteryTempChange: (Boolean) -> Unit,
  onResetDefaults: () -> Unit,
) {
  var previewBackdrop by remember { mutableStateOf(PreviewBackdrop.DARK_GAME) }
  var previewOrientation by remember { mutableStateOf(PreviewOrientation.PORTRAIT) }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 700.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        item {
          EditorialHeader(
            isRunning = uiState.isOverlayRunning,
            isPaused = uiState.isOverlayPaused,
            hasPermission = uiState.hasOverlayPermission,
            onToggleOverlay = onToggleOverlay,
            onTogglePause = onTogglePause,
            onRequestPermission = onRequestOverlayPermission,
          )
        }

        item {
          AnimatedVisibility(visible = !uiState.hasOverlayPermission) {
            PermissionRequiredCard(onGrantClick = onRequestOverlayPermission)
          }
        }

        item {
          QuickPresetsRow(onApplyPreset = onApplyPreset)
        }

        item {
          SideEdgePreviewStage(
            telemetry = uiState.telemetry,
            config = uiState.config,
            backdrop = previewBackdrop,
            orientation = previewOrientation,
            onBackdropChange = { previewBackdrop = it },
            onOrientationChange = { previewOrientation = it },
          )
        }

        item {
          LiveTelemetryGrid(
            telemetry = uiState.telemetry,
            tempUnit = uiState.config.tempUnit,
          )
        }

        item {
          BatteryEfficiencyCard(
            refreshInterval = uiState.config.refreshInterval,
            pauseOnScreenOff = uiState.config.pauseOnScreenOff,
            onRefreshIntervalChange = onRefreshIntervalChange,
            onPauseOnScreenOffChange = onPauseOnScreenOffChange,
          )
        }

        item {
          BankingAndGameSafetyCard(
            safeOpacityCap = uiState.config.safeOpacityCap,
            onSafeOpacityCapChange = onSafeOpacityCapChange,
          )
        }

        item {
          PlacementControlsCard(
            config = uiState.config,
            onEdgeSideChange = onEdgeSideChange,
            onVerticalPositionChange = onVerticalPositionChange,
            onSeparateLandscapePosChange = onSeparateLandscapePosChange,
            onLandscapeVerticalPositionChange = onLandscapeVerticalPositionChange,
            onEdgeMarginChange = onEdgeMarginChange,
            onScaleChange = onScaleChange,
          )
        }

        item {
          AppearanceControlsCard(
            config = uiState.config,
            onContentAlphaChange = onContentAlphaChange,
            onBackdropAlphaChange = onBackdropAlphaChange,
            onInkPresetChange = onInkPresetChange,
            onTempUnitChange = onTempUnitChange,
          )
        }

        item {
          VisibleMetricsCard(
            config = uiState.config,
            onShowSpeedChange = onShowSpeedChange,
            onShowWifiSignalChange = onShowWifiSignalChange,
            onShowWifiVersionChange = onShowWifiVersionChange,
            onShowBatteryPercentChange = onShowBatteryPercentChange,
            onShowBatteryTempChange = onShowBatteryTempChange,
            onResetDefaults = onResetDefaults,
          )
        }

        item { Spacer(modifier = Modifier.height(12.dp)) }
      }
    }
  }
}

@Composable
private fun EditorialHeader(
  isRunning: Boolean,
  isPaused: Boolean,
  hasPermission: Boolean,
  onToggleOverlay: (Boolean) -> Unit,
  onTogglePause: (Boolean) -> Unit,
  onRequestPermission: () -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "NetTherm HUD",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Portrait & Landscape · Times New Roman · Ultra-Low Power",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        StatusPill(isRunning = isRunning, isPaused = isPaused)
      }

      Spacer(modifier = Modifier.height(14.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text(
            text = if (isRunning) "Side-Edge HUD Active" else "Side-Edge HUD Off",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text =
              if (hasPermission) {
                "Auto-adapts to every portrait & landscape app. Also in Quick Settings."
              } else {
                "Allow overlay permission once, then toggle anytime with one tap."
              },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        if (isRunning) {
          OutlinedButton(
            onClick = { onTogglePause(!isPaused) },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("overlay_pause_button"),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
          ) {
            Icon(
              imageVector =
                if (isPaused) Icons.Outlined.PlayCircle else Icons.Outlined.PauseCircle,
              contentDescription = if (isPaused) "Resume overlay" else "Pause overlay",
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isPaused) "Resume" else "Pause")
          }
          Spacer(modifier = Modifier.width(8.dp))
        }

        Switch(
          checked = isRunning,
          onCheckedChange = { checked ->
            if (checked && !hasPermission) {
              onRequestPermission()
            } else {
              onToggleOverlay(checked)
            }
          },
          modifier = Modifier.testTag("overlay_master_switch"),
        )
      }
    }
  }
}

@Composable
private fun QuickPresetsRow(onApplyPreset: (HudPreset) -> Unit) {
  Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Text(
      text = "1-Tap Quick Setup",
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.padding(horizontal = 4.dp),
    )
    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      HudPreset.entries.forEach { preset ->
        Surface(
          modifier =
            Modifier.minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(14.dp))
              .clickable { onApplyPreset(preset) }
              .testTag("preset_${preset.name.lowercase()}"),
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          shape = RoundedCornerShape(14.dp),
        ) {
          Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(
              text = preset.label,
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.primary,
            )
            Text(
              text = preset.subtitle,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun StatusPill(isRunning: Boolean, isPaused: Boolean) {
  val containerColor =
    when {
      isRunning && !isPaused -> MaterialTheme.colorScheme.secondaryContainer
      isRunning && isPaused -> MaterialTheme.colorScheme.primaryContainer
      else -> MaterialTheme.colorScheme.surfaceVariant
    }
  val contentColor =
    when {
      isRunning && !isPaused -> MaterialTheme.colorScheme.onSecondaryContainer
      isRunning && isPaused -> MaterialTheme.colorScheme.onPrimaryContainer
      else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
  val dotColor =
    when {
      isRunning && !isPaused -> MaterialTheme.colorScheme.secondary
      isRunning && isPaused -> MaterialTheme.colorScheme.primary
      else -> MaterialTheme.colorScheme.outline
    }
  val label =
    when {
      isRunning && !isPaused -> "Live"
      isRunning && isPaused -> "Paused"
      else -> "Standby"
    }

  Surface(color = containerColor, shape = CircleShape) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(dotColor))
      Spacer(modifier = Modifier.width(6.dp))
      Text(text = label, style = MaterialTheme.typography.labelMedium, color = contentColor)
    }
  }
}

@Composable
private fun PermissionRequiredCard(onGrantClick: () -> Unit) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    shape = MaterialTheme.shapes.medium,
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
        Text(
          text = "Display Over Other Apps Required",
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Needed solely to draw the non-touchable side HUD across portrait & landscape apps.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
        )
      }
      Button(
        onClick = onGrantClick,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("grant_permission_button"),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
      ) {
        Text("Allow")
      }
    }
  }
}

@Composable
private fun SideEdgePreviewStage(
  telemetry: TelemetrySnapshot,
  config: OverlayConfig,
  backdrop: PreviewBackdrop,
  orientation: PreviewOrientation,
  onBackdropChange: (PreviewBackdrop) -> Unit,
  onOrientationChange: (PreviewOrientation) -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Live Transparent Preview",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          PreviewOrientation.entries.forEach { mode ->
            FilterChip(
              selected = orientation == mode,
              onClick = { onOrientationChange(mode) },
              leadingIcon = {
                Icon(
                  imageVector = Icons.Outlined.ScreenRotation,
                  contentDescription = mode.label,
                  modifier = Modifier.size(14.dp),
                )
              },
              label = { Text(mode.label, style = MaterialTheme.typography.labelSmall) },
            )
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        PreviewBackdrop.entries.forEach { option ->
          FilterChip(
            selected = option == backdrop,
            onClick = { onBackdropChange(option) },
            label = { Text(option.label, style = MaterialTheme.typography.labelSmall) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      val bgBrush =
        when (backdrop) {
          PreviewBackdrop.DARK_GAME ->
            Brush.linearGradient(listOf(Color(0xFF0A0E14), Color(0xFF17222E), Color(0xFF0E151B)))
          PreviewBackdrop.LIGHT_FEED ->
            Brush.linearGradient(listOf(Color(0xFFF3F5F8), Color(0xFFE3E8EF), Color(0xFFFDFEFE)))
          PreviewBackdrop.TWILIGHT ->
            Brush.linearGradient(listOf(Color(0xFF2B253A), Color(0xFF3E5066), Color(0xFF1E2D3D)))
        }
      val mockContentTint =
        if (backdrop == PreviewBackdrop.LIGHT_FEED) Color(0xFF1D2430) else Color(0xFFE7ECF2)

      val stageHeight = if (orientation == PreviewOrientation.LANDSCAPE) 134.dp else 184.dp
      val activePercent =
        if (orientation == PreviewOrientation.LANDSCAPE && config.separateLandscapePos) {
          config.landscapeVerticalPercent
        } else {
          config.verticalPositionPercent
        }

      BoxWithConstraints(
        modifier =
          Modifier.fillMaxWidth()
            .height(stageHeight)
            .clip(RoundedCornerShape(18.dp))
            .background(bgBrush)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp)),
      ) {
        val stageHeightPx = constraints.maxHeight.toFloat()

        // Simulated camera notch hint in landscape so user sees cutout-safe placement
        if (orientation == PreviewOrientation.LANDSCAPE) {
          Box(
            modifier =
              Modifier.align(Alignment.CenterStart)
                .padding(start = 6.dp)
                .size(width = 7.dp, height = 22.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.55f)),
          )
        }

        Column(
          modifier = Modifier.fillMaxSize().padding(16.dp),
          verticalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier =
                Modifier.width(92.dp)
                  .height(12.dp)
                  .clip(CircleShape)
                  .background(mockContentTint.copy(alpha = 0.14f)),
            )
            Box(
              modifier =
                Modifier.width(44.dp)
                  .height(12.dp)
                  .clip(CircleShape)
                  .background(mockContentTint.copy(alpha = 0.10f)),
            )
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Icon(
              imageVector = Icons.Outlined.TouchApp,
              contentDescription = "Non-touchable indicator",
              tint = mockContentTint.copy(alpha = 0.55f),
              modifier = Modifier.size(14.dp),
            )
            Text(
              text = "${orientation.label} mode · Cutout-safe · Zero touch contact",
              style = MaterialTheme.typography.labelSmall,
              color = mockContentTint.copy(alpha = 0.60f),
            )
          }
        }

        val edgeAlignment =
          if (config.edgeSide == EdgeSide.LEFT) Alignment.TopStart else Alignment.TopEnd
        val clampedY = (stageHeightPx * (activePercent * 0.68f)).roundToInt()

        AndroidView(
          factory = { context -> HudOverlayView(context) },
          update = { view -> view.updateState(telemetry, config) },
          modifier =
            Modifier.align(edgeAlignment)
              .padding(horizontal = config.edgeMarginDp.dp)
              .offset { IntOffset(0, clampedY) }
              .testTag("hud_live_preview"),
        )
      }
    }
  }
}

@Composable
private fun LiveTelemetryGrid(telemetry: TelemetrySnapshot, tempUnit: TempUnit) {
  val (speedVal, speedUnit) = TelemetryFormatter.formatSpeedStacked(telemetry.totalBytesPerSec)
  val rxInline = TelemetryFormatter.formatSpeedInline(telemetry.rxBytesPerSec)
  val txInline = TelemetryFormatter.formatSpeedInline(telemetry.txBytesPerSec)
  val tempStr = TelemetryFormatter.formatTemperature(telemetry.batteryTempCelsius, tempUnit)
  val thermalCategory = TelemetryFormatter.thermalCategoryLabel(telemetry.batteryTempCelsius)

  val tempTint =
    when {
      telemetry.batteryTempCelsius >= 43.0f -> ThermalCoral
      telemetry.batteryTempCelsius >= 39.5f -> WarmAmber
      else -> MaterialTheme.colorScheme.secondary
    }

  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      TelemetryTile(
        modifier = Modifier.weight(1f),
        icon = Icons.Outlined.Speed,
        label = "Live Speed",
        primaryValue = "$speedVal $speedUnit",
        secondaryValue = "↓ $rxInline  ↑ $txInline",
        accentColor = MaterialTheme.colorScheme.primary,
      )
      TelemetryTile(
        modifier = Modifier.weight(1f),
        icon = Icons.Outlined.Wifi,
        label = "Wi-Fi Signal & Gen",
        primaryValue =
          if (telemetry.isWifiConnected) {
            "Wi-Fi ${telemetry.wifiVersionLabel} · ${telemetry.wifiSignalLevel}/4"
          } else {
            "Disconnected"
          },
        secondaryValue =
          if (telemetry.isWifiConnected) {
            "${telemetry.wifiRssiDbm} dBm · ${telemetry.wifiLinkSpeedMbps} Mbps"
          } else {
            telemetry.wifiStandardDescription
          },
        accentColor = MaterialTheme.colorScheme.secondary,
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      TelemetryTile(
        modifier = Modifier.weight(1f),
        icon = Icons.Outlined.BatteryChargingFull,
        label = "Battery Life",
        primaryValue = "${telemetry.batteryPercent}%",
        secondaryValue =
          if (telemetry.batteryVoltageMv > 0) {
            "${telemetry.batteryStatusLabel} · ${String.format(Locale.US, "%.2fV", telemetry.batteryVoltageMv / 1000f)}"
          } else {
            telemetry.batteryStatusLabel
          },
        accentColor = MaterialTheme.colorScheme.primary,
      )
      TelemetryTile(
        modifier = Modifier.weight(1f),
        icon = Icons.Outlined.Thermostat,
        label = "Battery Temp",
        primaryValue = tempStr,
        secondaryValue = "Thermal: $thermalCategory",
        accentColor = tempTint,
      )
    }
  }
}

@Composable
private fun TelemetryTile(
  modifier: Modifier = Modifier,
  icon: ImageVector,
  label: String,
  primaryValue: String,
  secondaryValue: String,
  accentColor: Color,
) {
  Card(
    modifier = modifier,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.medium,
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = icon,
          contentDescription = label,
          tint = accentColor,
          modifier = Modifier.size(16.dp),
        )
        Text(
          text = label,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = primaryValue,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = secondaryValue,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun BatteryEfficiencyCard(
  refreshInterval: RefreshInterval,
  pauseOnScreenOff: Boolean,
  onRefreshIntervalChange: (RefreshInterval) -> Unit,
  onPauseOnScreenOffChange: (Boolean) -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.Bolt,
          contentDescription = "Low battery consumption",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = "Low Battery Consumption",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Text(
        text = "Zero wakelocks, dirty-checked canvas redraws, and automatic deep sleep when your screen turns off.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        RefreshInterval.entries.forEach { option ->
          FilterChip(
            modifier = Modifier.weight(1f).testTag("refresh_${option.name.lowercase()}"),
            selected = refreshInterval == option,
            onClick = { onRefreshIntervalChange(option) },
            label = {
              Text(
                text = option.label,
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
              )
            },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text(
            text = "Zero-Drain Sleep on Screen Off",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "Suspends all polling immediately whenever the screen locks.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Switch(
          checked = pauseOnScreenOff,
          onCheckedChange = onPauseOnScreenOffChange,
          modifier = Modifier.testTag("sleep_screen_off_switch"),
        )
      }
    }
  }
}

@Composable
private fun BankingAndGameSafetyCard(
  safeOpacityCap: Boolean,
  onSafeOpacityCapChange: (Boolean) -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.Shield,
          contentDescription = "Banking and game safety",
          tint = MaterialTheme.colorScheme.secondary,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = "Banking, Games & Universal App Safety",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text =
          "• Anti-cheat & banking clean: No Accessibility Service, no Usage Stats, no screen capture, and no installed-app scanning.\n" +
            "• Portrait & landscape cutout-aware: Automatically dodges side camera holes and navigation bars in fullscreen games and videos.\n" +
            "• Quick Settings Tile: Add \"NetTherm HUD\" to your Quick Settings panel to toggle from any app in 1 tap.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text(
            text = "Touch-Safe Opacity Cap (≤ 80%)",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "Keeps window alpha under Android's obscuring threshold so taps underneath are never blocked.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Switch(
          checked = safeOpacityCap,
          onCheckedChange = onSafeOpacityCapChange,
          modifier = Modifier.testTag("safe_opacity_switch"),
        )
      }
    }
  }
}

@Composable
private fun PlacementControlsCard(
  config: OverlayConfig,
  onEdgeSideChange: (EdgeSide) -> Unit,
  onVerticalPositionChange: (Float) -> Unit,
  onSeparateLandscapePosChange: (Boolean) -> Unit,
  onLandscapeVerticalPositionChange: (Float) -> Unit,
  onEdgeMarginChange: (Float) -> Unit,
  onScaleChange: (Float) -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.Layers,
          contentDescription = "Side placement",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = "Side Edge Placement & Size",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        EdgeChoiceChip(
          modifier = Modifier.weight(1f).testTag("side_left_chip"),
          label = "Left Side",
          selected = config.edgeSide == EdgeSide.LEFT,
          onClick = { onEdgeSideChange(EdgeSide.LEFT) },
        )
        EdgeChoiceChip(
          modifier = Modifier.weight(1f).testTag("side_right_chip"),
          label = "Right Side",
          selected = config.edgeSide == EdgeSide.RIGHT,
          onClick = { onEdgeSideChange(EdgeSide.RIGHT) },
        )
      }

      LabeledSlider(
        title = "Portrait Vertical Position",
        valueText = "${(config.verticalPositionPercent * 100).roundToInt()}%",
        value = config.verticalPositionPercent,
        valueRange = 0.03f..0.88f,
        onValueChange = onVerticalPositionChange,
        testTag = "vertical_position_slider",
      )

      Row(
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text(
            text = "Separate Landscape Height",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "Tuck cleanly near the top-side edge in landscape games & videos.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Switch(
          checked = config.separateLandscapePos,
          onCheckedChange = onSeparateLandscapePosChange,
          modifier = Modifier.testTag("separate_landscape_switch"),
        )
      }

      AnimatedVisibility(visible = config.separateLandscapePos) {
        LabeledSlider(
          title = "Landscape Vertical Position",
          valueText = "${(config.landscapeVerticalPercent * 100).roundToInt()}%",
          value = config.landscapeVerticalPercent,
          valueRange = 0.03f..0.85f,
          onValueChange = onLandscapeVerticalPositionChange,
          testTag = "landscape_position_slider",
        )
      }

      LabeledSlider(
        title = "Side Edge Margin",
        valueText = "${config.edgeMarginDp.roundToInt()} dp",
        value = config.edgeMarginDp,
        valueRange = 0f..24f,
        onValueChange = onEdgeMarginChange,
        testTag = "edge_margin_slider",
      )

      LabeledSlider(
        title = "Compact HUD Scale",
        valueText = String.format(Locale.US, "%.2fx", config.scale),
        value = config.scale,
        valueRange = 0.75f..1.50f,
        onValueChange = onScaleChange,
        testTag = "hud_scale_slider",
      )
    }
  }
}

@Composable
private fun EdgeChoiceChip(
  modifier: Modifier = Modifier,
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
) {
  Surface(
    modifier =
      modifier.minimumInteractiveComponentSize().clip(RoundedCornerShape(12.dp)).clickable(
        onClick = onClick,
      ),
    color =
      if (selected) MaterialTheme.colorScheme.primaryContainer
      else MaterialTheme.colorScheme.surfaceVariant,
    border =
      BorderStroke(
        width = 1.dp,
        color =
          if (selected) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.outlineVariant,
      ),
    shape = RoundedCornerShape(12.dp),
  ) {
    Box(modifier = Modifier.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        color =
          if (selected) MaterialTheme.colorScheme.onPrimaryContainer
          else MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun AppearanceControlsCard(
  config: OverlayConfig,
  onContentAlphaChange: (Float) -> Unit,
  onBackdropAlphaChange: (Float) -> Unit,
  onInkPresetChange: (InkPreset) -> Unit,
  onTempUnitChange: (TempUnit) -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(
        text = "Transparency & Serif Ink",
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )

      LabeledSlider(
        title = "Glyph & Text Opacity",
        valueText = "${(config.contentAlpha * 100).roundToInt()}%",
        value = config.contentAlpha,
        valueRange = 0.35f..1.0f,
        onValueChange = onContentAlphaChange,
        testTag = "content_alpha_slider",
      )

      LabeledSlider(
        title = "Backdrop Tint (0% = Pure Transparent)",
        valueText = "${(config.backdropAlpha * 100).roundToInt()}%",
        value = config.backdropAlpha,
        valueRange = 0.0f..0.60f,
        onValueChange = onBackdropAlphaChange,
        testTag = "backdrop_alpha_slider",
      )

      Text(
        text = "Overlay Ink Color",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        InkPreset.entries.forEach { preset ->
          val selected = config.inkPreset == preset
          FilterChip(
            selected = selected,
            onClick = { onInkPresetChange(preset) },
            leadingIcon = {
              Box(
                modifier =
                  Modifier.size(12.dp)
                    .clip(CircleShape)
                    .background(Color(preset.argb))
                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
              )
            },
            label = { Text(preset.label, style = MaterialTheme.typography.labelMedium) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
          )
        }
      }

      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

      Row(
        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Temperature Unit",
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = config.tempUnit == TempUnit.CELSIUS,
            onClick = { onTempUnitChange(TempUnit.CELSIUS) },
            label = { Text("°C Celsius") },
            modifier = Modifier.testTag("unit_celsius_chip"),
          )
          FilterChip(
            selected = config.tempUnit == TempUnit.FAHRENHEIT,
            onClick = { onTempUnitChange(TempUnit.FAHRENHEIT) },
            label = { Text("°F Fahrenheit") },
            modifier = Modifier.testTag("unit_fahrenheit_chip"),
          )
        }
      }
    }
  }
}

@Composable
private fun VisibleMetricsCard(
  config: OverlayConfig,
  onShowSpeedChange: (Boolean) -> Unit,
  onShowWifiSignalChange: (Boolean) -> Unit,
  onShowWifiVersionChange: (Boolean) -> Unit,
  onShowBatteryPercentChange: (Boolean) -> Unit,
  onShowBatteryTempChange: (Boolean) -> Unit,
  onResetDefaults: () -> Unit,
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    shape = MaterialTheme.shapes.large,
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "Displayed HUD Metrics",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        TextButton(
          onClick = onResetDefaults,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("reset_defaults_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.RestartAlt,
            contentDescription = "Reset defaults",
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text("Reset")
        }
      }

      MetricSwitchRow(
        label = "Live Wi-Fi Speed (KB/S · MB/S)",
        checked = config.showSpeed,
        onCheckedChange = onShowSpeedChange,
        testTag = "toggle_speed",
      )
      MetricSwitchRow(
        label = "Live Wi-Fi Signal Bars & TX/RX Arrows",
        checked = config.showWifiSignal,
        onCheckedChange = onShowWifiSignalChange,
        testTag = "toggle_wifi_signal",
      )
      MetricSwitchRow(
        label = "Wi-Fi Version Number (4 / 5 / 6 / 7)",
        checked = config.showWifiVersion,
        onCheckedChange = onShowWifiVersionChange,
        testTag = "toggle_wifi_version",
      )
      MetricSwitchRow(
        label = "Battery Life Percentage (%)",
        checked = config.showBatteryPercent,
        onCheckedChange = onShowBatteryPercentChange,
        testTag = "toggle_battery_percent",
      )
      MetricSwitchRow(
        label = "Battery Temperature Status",
        checked = config.showBatteryTemp,
        onCheckedChange = onShowBatteryTempChange,
        testTag = "toggle_battery_temp",
      )
    }
  }
}

@Composable
private fun MetricSwitchRow(
  label: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  testTag: String,
) {
  Row(
    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().padding(vertical = 2.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurface,
      modifier = Modifier.weight(1f).padding(end = 12.dp),
    )
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      modifier = Modifier.testTag(testTag),
    )
  }
}

@Composable
private fun LabeledSlider(
  title: String,
  valueText: String,
  value: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit,
  testTag: String,
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface,
      )
      Text(
        text = valueText,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
      )
    }
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      modifier = Modifier.fillMaxWidth().testTag(testTag),
      colors =
        SliderDefaults.colors(
          thumbColor = MaterialTheme.colorScheme.primary,
          activeTrackColor = MaterialTheme.colorScheme.primary,
        ),
    )
  }
}
