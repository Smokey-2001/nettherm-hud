package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkColorScheme =
  darkColorScheme(
    primary = BrassPrimary,
    onPrimary = BrassOnPrimary,
    primaryContainer = BrassContainer,
    onPrimaryContainer = BrassOnContainer,
    secondary = TelemetryMint,
    onSecondary = TelemetryOnMint,
    secondaryContainer = TelemetryMintContainer,
    onSecondaryContainer = TelemetryOnMintContainer,
    tertiary = SkyTertiary,
    background = ObsidianBackground,
    onBackground = IvoryText,
    surface = ObsidianSurface,
    onSurface = IvoryText,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = MutedSlateText,
    outline = ObsidianOutline,
    outlineVariant = ObsidianOutlineVariant,
    error = ThermalCoral,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = LightBrassPrimary,
    onPrimary = PaperSurface,
    primaryContainer = LightBrassContainer,
    onPrimaryContainer = LightBrassOnContainer,
    secondary = LightMintSecondary,
    onSecondary = PaperSurface,
    secondaryContainer = LightMintContainer,
    onSecondaryContainer = LightMintOnContainer,
    tertiary = SkyTertiary,
    background = PaperBackground,
    onBackground = InkText,
    surface = PaperSurface,
    onSurface = InkText,
    surfaceVariant = PaperSurfaceVariant,
    onSurfaceVariant = MutedInkText,
    outline = PaperOutline,
    outlineVariant = PaperOutlineVariant,
    error = ThermalCoral,
  )

private val AppShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun NetThermHudTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    shapes = AppShapes,
    content = content,
  )
}
