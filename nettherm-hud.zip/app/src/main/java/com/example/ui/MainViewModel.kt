package com.example.ui

import android.app.Application
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.OverlayPreferencesRepository
import com.example.data.OverlayServiceState
import com.example.data.TelemetryMonitor
import com.example.model.EdgeSide
import com.example.model.InkPreset
import com.example.model.OverlayConfig
import com.example.model.RefreshInterval
import com.example.model.TelemetrySnapshot
import com.example.model.TempUnit
import com.example.overlay.OverlayService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class HudPreset(val label: String, val subtitle: String) {
  BALANCED_SIDE("Balanced Side", "2s Eco · Transparent"),
  GAME_LANDSCAPE("Game Safe", "Compact · 1s Live"),
  ULTRA_BATTERY("Ultra Battery", "3s Ultra · Minimal"),
}

data class MainUiState(
  val telemetry: TelemetrySnapshot = TelemetrySnapshot(),
  val config: OverlayConfig = OverlayConfig(),
  val isOverlayRunning: Boolean = false,
  val isOverlayPaused: Boolean = false,
  val hasOverlayPermission: Boolean = false,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val preferencesRepository = OverlayPreferencesRepository(application)
  private val telemetryMonitor = TelemetryMonitor(application)
  private val permissionFlow = MutableStateFlow(Settings.canDrawOverlays(application))

  private val refreshFlow =
    preferencesRepository.configFlow.map { it.refreshInterval }.distinctUntilChanged()
  private val screenOffPauseFlow =
    preferencesRepository.configFlow.map { it.pauseOnScreenOff }.distinctUntilChanged()

  val uiState: StateFlow<MainUiState> =
    combine(
        telemetryMonitor.observeTelemetry(refreshFlow, screenOffPauseFlow),
        preferencesRepository.configFlow,
        OverlayServiceState.isRunning,
        OverlayServiceState.isPaused,
        permissionFlow,
      ) { telemetry, config, isRunning, isPaused, hasPermission ->
        MainUiState(
          telemetry = telemetry,
          config = config,
          isOverlayRunning = isRunning,
          isOverlayPaused = isPaused,
          hasOverlayPermission = hasPermission,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = MainUiState(hasOverlayPermission = Settings.canDrawOverlays(application)),
      )

  fun refreshOverlayPermission() {
    permissionFlow.value = Settings.canDrawOverlays(getApplication())
  }

  fun setOverlayEnabled(enabled: Boolean) {
    val ctx = getApplication<Application>()
    val canDraw = Settings.canDrawOverlays(ctx)
    permissionFlow.value = canDraw
    if (enabled && canDraw) {
      OverlayService.start(ctx)
    } else if (!enabled) {
      OverlayService.stop(ctx)
    }
  }

  fun setOverlayPaused(paused: Boolean) {
    OverlayService.setPaused(getApplication(), paused)
  }

  fun applyQuickPreset(preset: HudPreset) {
    updateConfig { current ->
      when (preset) {
        HudPreset.BALANCED_SIDE ->
          current.copy(
            edgeSide = EdgeSide.RIGHT,
            verticalPositionPercent = 0.18f,
            separateLandscapePos = true,
            landscapeVerticalPercent = 0.10f,
            scale = 1.0f,
            contentAlpha = 0.78f,
            backdropAlpha = 0.0f,
            safeOpacityCap = true,
            refreshInterval = RefreshInterval.BALANCED_2S,
            pauseOnScreenOff = true,
            showSpeed = true,
            showWifiSignal = true,
            showWifiVersion = true,
            showBatteryPercent = true,
            showBatteryTemp = true,
          )
        HudPreset.GAME_LANDSCAPE ->
          current.copy(
            edgeSide = EdgeSide.RIGHT,
            verticalPositionPercent = 0.14f,
            separateLandscapePos = true,
            landscapeVerticalPercent = 0.06f,
            edgeMarginDp = 8f,
            scale = 0.90f,
            contentAlpha = 0.75f,
            backdropAlpha = 0.0f,
            safeOpacityCap = true,
            refreshInterval = RefreshInterval.LIVE_1S,
            pauseOnScreenOff = true,
            showSpeed = true,
            showWifiSignal = true,
            showWifiVersion = true,
            showBatteryPercent = true,
            showBatteryTemp = true,
          )
        HudPreset.ULTRA_BATTERY ->
          current.copy(
            scale = 0.90f,
            contentAlpha = 0.72f,
            backdropAlpha = 0.0f,
            safeOpacityCap = true,
            refreshInterval = RefreshInterval.ULTRA_3S,
            pauseOnScreenOff = true,
            showSpeed = false,
            showWifiSignal = true,
            showWifiVersion = true,
            showBatteryPercent = true,
            showBatteryTemp = true,
          )
      }
    }
  }

  fun setEdgeSide(side: EdgeSide) {
    updateConfig { it.copy(edgeSide = side) }
  }

  fun setVerticalPosition(percent: Float) {
    updateConfig { it.copy(verticalPositionPercent = percent) }
  }

  fun setSeparateLandscapePos(enabled: Boolean) {
    updateConfig { it.copy(separateLandscapePos = enabled) }
  }

  fun setLandscapeVerticalPosition(percent: Float) {
    updateConfig { it.copy(landscapeVerticalPercent = percent) }
  }

  fun setEdgeMarginDp(marginDp: Float) {
    updateConfig { it.copy(edgeMarginDp = marginDp) }
  }

  fun setScale(scale: Float) {
    updateConfig { it.copy(scale = scale) }
  }

  fun setContentAlpha(alpha: Float) {
    updateConfig { it.copy(contentAlpha = alpha) }
  }

  fun setBackdropAlpha(alpha: Float) {
    updateConfig { it.copy(backdropAlpha = alpha) }
  }

  fun setSafeOpacityCap(enabled: Boolean) {
    updateConfig { it.copy(safeOpacityCap = enabled) }
  }

  fun setRefreshInterval(interval: RefreshInterval) {
    updateConfig { it.copy(refreshInterval = interval) }
  }

  fun setPauseOnScreenOff(enabled: Boolean) {
    updateConfig { it.copy(pauseOnScreenOff = enabled) }
  }

  fun setInkPreset(preset: InkPreset) {
    updateConfig { it.copy(inkPreset = preset) }
  }

  fun setTempUnit(unit: TempUnit) {
    updateConfig { it.copy(tempUnit = unit) }
  }

  fun setShowSpeed(show: Boolean) {
    updateConfig { it.copy(showSpeed = show) }
  }

  fun setShowWifiSignal(show: Boolean) {
    updateConfig { it.copy(showWifiSignal = show) }
  }

  fun setShowWifiVersion(show: Boolean) {
    updateConfig { it.copy(showWifiVersion = show) }
  }

  fun setShowBatteryPercent(show: Boolean) {
    updateConfig { it.copy(showBatteryPercent = show) }
  }

  fun setShowBatteryTemp(show: Boolean) {
    updateConfig { it.copy(showBatteryTemp = show) }
  }

  fun resetDefaults() {
    viewModelScope.launch { preferencesRepository.updateConfig { OverlayConfig() } }
  }

  private fun updateConfig(transform: (OverlayConfig) -> OverlayConfig) {
    viewModelScope.launch { preferencesRepository.updateConfig(transform) }
  }
}
