package com.example.overlay

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.example.MainActivity
import com.example.data.OverlayServiceState

class HudQuickTileService : TileService() {

  override fun onStartListening() {
    super.onStartListening()
    syncTileState()
  }

  override fun onClick() {
    super.onClick()
    if (!Settings.canDrawOverlays(this)) {
      val intent =
        Intent(this, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        val pendingIntent =
          PendingIntent.getActivity(
            this,
            20,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
          )
        startActivityAndCollapse(pendingIntent)
      } else {
        @Suppress("DEPRECATION")
        startActivityAndCollapse(intent)
      }
      return
    }

    if (OverlayServiceState.isRunning.value) {
      OverlayService.stop(this)
    } else {
      OverlayService.start(this)
    }
    syncTileState()
  }

  private fun syncTileState() {
    val tile = qsTile ?: return
    val hasPerm = Settings.canDrawOverlays(this)
    val running = OverlayServiceState.isRunning.value
    tile.state =
      when {
        !hasPerm -> Tile.STATE_INACTIVE
        running -> Tile.STATE_ACTIVE
        else -> Tile.STATE_INACTIVE
      }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      tile.subtitle =
        when {
          !hasPerm -> "Grant permission"
          running -> "Active on edge"
          else -> "Off"
        }
    }
    tile.updateTile()
  }
}
