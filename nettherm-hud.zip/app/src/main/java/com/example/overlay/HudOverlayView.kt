package com.example.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.View
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.model.InkPreset
import com.example.model.OverlayConfig
import com.example.model.TelemetryFormatter
import com.example.model.TelemetrySnapshot
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

class HudOverlayView @JvmOverloads constructor(
  context: Context,
  attrs: AttributeSet? = null,
) : View(context, attrs) {

  private var telemetry: TelemetrySnapshot = TelemetrySnapshot()
  private var config: OverlayConfig = OverlayConfig()

  // Cached formatted strings & rendered state for zero-allocation draws and dirty-check skipping
  private var cachedSpeedNum: String = "0.00"
  private var cachedSpeedUnit: String = "KB/S"
  private var cachedBatteryPart: String = "0%"
  private var cachedTempPart: String = "0.0°C"
  private var cachedBatteryLine: String = "0% · 0.0°C"
  private var hasInitializedRenderCache: Boolean = false

  private val timesTypeface: Typeface =
    runCatching { ResourcesCompat.getFont(context, R.font.tinos) }.getOrNull() ?: Typeface.SERIF

  private val density = context.resources.displayMetrics.density

  private val textPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      typeface = timesTypeface
      textAlign = Paint.Align.LEFT
    }

  private val arcPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeCap = Paint.Cap.ROUND
    }

  private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

  private val backdropPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

  private val arcRect = RectF()
  private val backdropRect = RectF()
  private val trianglePath = Path()

  private fun dp(value: Float): Float = value * density * config.scale

  fun updateState(newTelemetry: TelemetrySnapshot, newConfig: OverlayConfig) {
    val (nextSpeedNum, nextSpeedUnit) =
      TelemetryFormatter.formatSpeedStacked(newTelemetry.totalBytesPerSec)
    val nextBatteryPart = if (newConfig.showBatteryPercent) "${newTelemetry.batteryPercent}%" else ""
    val nextTempPart =
      if (newConfig.showBatteryTemp) {
        TelemetryFormatter.formatTemperature(newTelemetry.batteryTempCelsius, newConfig.tempUnit)
      } else {
        ""
      }
    val nextSep = if (newConfig.showBatteryPercent && newConfig.showBatteryTemp) " · " else ""
    val nextBatteryLine = nextBatteryPart + nextSep + nextTempPart

    val prevTxActive = telemetry.txBytesPerSec > 0L
    val nextTxActive = newTelemetry.txBytesPerSec > 0L
    val prevRxActive = telemetry.rxBytesPerSec > 0L
    val nextRxActive = newTelemetry.rxBytesPerSec > 0L

    val sizeAffectingChanged =
      !hasInitializedRenderCache ||
        config.scale != newConfig.scale ||
        config.showSpeed != newConfig.showSpeed ||
        config.showWifiSignal != newConfig.showWifiSignal ||
        config.showWifiVersion != newConfig.showWifiVersion ||
        config.showBatteryPercent != newConfig.showBatteryPercent ||
        config.showBatteryTemp != newConfig.showBatteryTemp ||
        config.backdropAlpha != newConfig.backdropAlpha ||
        telemetry.wifiVersionLabel != newTelemetry.wifiVersionLabel ||
        cachedSpeedNum != nextSpeedNum ||
        cachedSpeedUnit != nextSpeedUnit ||
        cachedBatteryLine != nextBatteryLine

    val visualChanged =
      sizeAffectingChanged ||
        config.contentAlpha != newConfig.contentAlpha ||
        config.inkPreset != newConfig.inkPreset ||
        telemetry.isWifiConnected != newTelemetry.isWifiConnected ||
        telemetry.wifiSignalLevel != newTelemetry.wifiSignalLevel ||
        prevTxActive != nextTxActive ||
        prevRxActive != nextRxActive ||
        thermalTier(telemetry.batteryTempCelsius) != thermalTier(newTelemetry.batteryTempCelsius)

    telemetry = newTelemetry
    config = newConfig
    cachedSpeedNum = nextSpeedNum
    cachedSpeedUnit = nextSpeedUnit
    cachedBatteryPart = nextBatteryPart
    cachedTempPart = nextTempPart
    cachedBatteryLine = nextBatteryLine
    hasInitializedRenderCache = true

    if (!visualChanged) {
      return
    }
    if (sizeAffectingChanged) {
      requestLayout()
    }
    invalidate()
  }

  private fun thermalTier(tempCelsius: Float): Int =
    when {
      tempCelsius >= 43.0f -> 2
      tempCelsius >= 39.5f -> 1
      else -> 0
    }

  override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
    val padH = if (config.backdropAlpha > 0.01f) dp(6f) else dp(3f)
    val padV = if (config.backdropAlpha > 0.01f) dp(4f) else dp(2f)

    val hasWifiRow = config.showSpeed || config.showWifiSignal || config.showWifiVersion
    val hasBatteryRow = config.showBatteryPercent || config.showBatteryTemp

    var row1Width = 0f
    var row1Height = 0f

    if (hasWifiRow) {
      if (config.showSpeed) {
        textPaint.textSize = dp(10.5f)
        val numW = textPaint.measureText(cachedSpeedNum)
        textPaint.textSize = dp(6.6f)
        val unitW = textPaint.measureText(cachedSpeedUnit)
        row1Width += max(numW, unitW) + dp(3.5f)
        row1Height = max(row1Height, dp(18.5f))
      }

      if (config.showWifiVersion) {
        textPaint.textSize = dp(8.2f)
        val verW = textPaint.measureText(telemetry.wifiVersionLabel)
        row1Width += verW + dp(1.0f)
        row1Height = max(row1Height, dp(17f))
      }

      if (config.showWifiSignal) {
        row1Width += dp(22.5f)
        row1Height = max(row1Height, dp(17f))
      }
    }

    var row2Width = 0f
    var row2Height = 0f
    if (hasBatteryRow) {
      textPaint.textSize = dp(10.2f)
      row2Width = textPaint.measureText(cachedBatteryLine)
      row2Height = dp(12.5f)
    }

    val rowGap = if (hasWifiRow && hasBatteryRow) dp(2.0f) else 0f
    val contentW = max(row1Width, row2Width).coerceAtLeast(dp(24f))
    val contentH = (row1Height + rowGap + row2Height).coerceAtLeast(dp(16f))

    val desiredW = ceil((contentW + padH * 2f).toDouble()).toInt()
    val desiredH = ceil((contentH + padV * 2f).toDouble()).toInt()

    setMeasuredDimension(
      resolveSize(desiredW, widthMeasureSpec),
      resolveSize(desiredH, heightMeasureSpec),
    )
  }

  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)

    val padH = if (config.backdropAlpha > 0.01f) dp(6f) else dp(3f)
    val padV = if (config.backdropAlpha > 0.01f) dp(4f) else dp(2f)

    val baseInk = config.inkPreset.argb
    val contentAlphaInt = (config.contentAlpha.coerceIn(0.25f, 1.0f) * 255f).roundToInt()
    val inactiveAlphaInt = (contentAlphaInt * 0.28f).roundToInt()

    val isDarkInk = config.inkPreset == InkPreset.OBSIDIAN_INK
    val shadowColor =
      if (isDarkInk) {
        Color.argb((contentAlphaInt * 0.55f).roundToInt(), 255, 255, 255)
      } else {
        Color.argb((contentAlphaInt * 0.72f).roundToInt(), 0, 0, 0)
      }
    val useShadow = config.backdropAlpha < 0.25f

    if (config.backdropAlpha > 0.01f) {
      val bgAlpha = (config.backdropAlpha.coerceIn(0f, 0.75f) * 255f).roundToInt()
      backdropPaint.color =
        if (isDarkInk) Color.argb(bgAlpha, 244, 240, 232) else Color.argb(bgAlpha, 12, 14, 18)
      backdropRect.set(0f, 0f, width.toFloat(), height.toFloat())
      val radius = dp(8f)
      canvas.drawRoundRect(backdropRect, radius, radius, backdropPaint)
    }

    val hasWifiRow = config.showSpeed || config.showWifiSignal || config.showWifiVersion
    val hasBatteryRow = config.showBatteryPercent || config.showBatteryTemp

    var cursorY = padV

    if (hasWifiRow) {
      val row1Height = dp(18.5f)
      drawWifiRow(
        canvas = canvas,
        startX = padH,
        topY = cursorY,
        rowHeight = row1Height,
        baseInk = baseInk,
        activeAlpha = contentAlphaInt,
        inactiveAlpha = inactiveAlphaInt,
        shadowColor = shadowColor,
        useShadow = useShadow,
      )
      cursorY += row1Height + if (hasBatteryRow) dp(2.0f) else 0f
    }

    if (hasBatteryRow) {
      drawBatteryRow(
        canvas = canvas,
        centerX = width / 2f,
        topY = cursorY,
        baseInk = baseInk,
        activeAlpha = contentAlphaInt,
        shadowColor = shadowColor,
        useShadow = useShadow,
      )
    }
  }

  private fun drawWifiRow(
    canvas: Canvas,
    startX: Float,
    topY: Float,
    rowHeight: Float,
    baseInk: Int,
    activeAlpha: Int,
    inactiveAlpha: Int,
    shadowColor: Int,
    useShadow: Boolean,
  ) {
    var x = startX
    val activeColor = applyAlpha(baseInk, activeAlpha)
    val inactiveColor = applyAlpha(baseInk, inactiveAlpha)

    if (useShadow) {
      textPaint.setShadowLayer(dp(1.4f), 0f, dp(0.6f), shadowColor)
    } else {
      textPaint.clearShadowLayer()
    }

    if (config.showSpeed) {
      textPaint.color = activeColor
      textPaint.textAlign = Paint.Align.CENTER

      textPaint.textSize = dp(10.5f)
      val numW = textPaint.measureText(cachedSpeedNum)
      textPaint.textSize = dp(6.6f)
      val unitW = textPaint.measureText(cachedSpeedUnit)
      val blockW = max(numW, unitW)
      val blockCenterX = x + blockW / 2f

      textPaint.textSize = dp(10.5f)
      canvas.drawText(cachedSpeedNum, blockCenterX, topY + dp(9.5f), textPaint)

      textPaint.textSize = dp(6.6f)
      canvas.drawText(cachedSpeedUnit, blockCenterX, topY + dp(16.5f), textPaint)

      x += blockW + dp(3.5f)
    }

    if (config.showWifiVersion) {
      textPaint.textAlign = Paint.Align.LEFT
      textPaint.textSize = dp(8.2f)
      textPaint.color = if (telemetry.isWifiConnected) activeColor else inactiveColor
      val verStr = telemetry.wifiVersionLabel
      canvas.drawText(verStr, x, topY + rowHeight - dp(2.2f), textPaint)
      x += textPaint.measureText(verStr) + dp(1.0f)
    }

    if (config.showWifiSignal) {
      val wifiCenterX = x + dp(8.0f)
      val dotCenterY = topY + rowHeight - dp(3.2f)
      val level = if (telemetry.isWifiConnected) telemetry.wifiSignalLevel else 0

      val dotRadius = dp(1.45f)
      if (useShadow) {
        fillPaint.color = shadowColor
        canvas.drawCircle(wifiCenterX, dotCenterY + dp(0.6f), dotRadius, fillPaint)
      }
      fillPaint.color = if (level >= 1) activeColor else inactiveColor
      canvas.drawCircle(wifiCenterX, dotCenterY, dotRadius, fillPaint)

      arcPaint.strokeWidth = dp(1.65f)
      val radii = floatArrayOf(dp(4.2f), dp(7.1f), dp(10.0f))
      for (i in radii.indices) {
        val r = radii[i]
        val barTier = i + 2
        arcRect.set(wifiCenterX - r, dotCenterY - r, wifiCenterX + r, dotCenterY + r)

        if (useShadow) {
          arcPaint.color = shadowColor
          arcRect.offset(0f, dp(0.6f))
          canvas.drawArc(arcRect, 226f, 88f, false, arcPaint)
          arcRect.offset(0f, -dp(0.6f))
        }

        arcPaint.color = if (level >= barTier) activeColor else inactiveColor
        canvas.drawArc(arcRect, 226f, 88f, false, arcPaint)
      }

      if (!telemetry.isWifiConnected) {
        arcPaint.strokeWidth = dp(1.2f)
        arcPaint.color = activeColor
        canvas.drawLine(
          wifiCenterX - dp(6f),
          dotCenterY - dp(9.5f),
          wifiCenterX + dp(6f),
          dotCenterY + dp(0.5f),
          arcPaint,
        )
      }

      val triCenterX = wifiCenterX + dp(10.2f)
      val triHalfW = dp(2.0f)
      val triH = dp(2.4f)

      val upTopY = dotCenterY - dp(7.0f)
      trianglePath.reset()
      trianglePath.moveTo(triCenterX, upTopY)
      trianglePath.lineTo(triCenterX - triHalfW, upTopY + triH)
      trianglePath.lineTo(triCenterX + triHalfW, upTopY + triH)
      trianglePath.close()

      if (useShadow) {
        fillPaint.color = shadowColor
        canvas.save()
        canvas.translate(0f, dp(0.5f))
        canvas.drawPath(trianglePath, fillPaint)
        canvas.restore()
      }
      fillPaint.color = if (telemetry.txBytesPerSec > 0L) activeColor else inactiveColor
      canvas.drawPath(trianglePath, fillPaint)

      val downTopY = dotCenterY - dp(3.0f)
      trianglePath.reset()
      trianglePath.moveTo(triCenterX - triHalfW, downTopY)
      trianglePath.lineTo(triCenterX + triHalfW, downTopY)
      trianglePath.lineTo(triCenterX, downTopY + triH)
      trianglePath.close()

      if (useShadow) {
        fillPaint.color = shadowColor
        canvas.save()
        canvas.translate(0f, dp(0.5f))
        canvas.drawPath(trianglePath, fillPaint)
        canvas.restore()
      }
      fillPaint.color = if (telemetry.rxBytesPerSec > 0L) activeColor else inactiveColor
      canvas.drawPath(trianglePath, fillPaint)
    }
  }

  private fun drawBatteryRow(
    canvas: Canvas,
    centerX: Float,
    topY: Float,
    baseInk: Int,
    activeAlpha: Int,
    shadowColor: Int,
    useShadow: Boolean,
  ) {
    textPaint.textSize = dp(10.2f)
    textPaint.textAlign = Paint.Align.LEFT
    if (useShadow) {
      textPaint.setShadowLayer(dp(1.4f), 0f, dp(0.6f), shadowColor)
    } else {
      textPaint.clearShadowLayer()
    }

    val sepPart = if (config.showBatteryPercent && config.showBatteryTemp) " · " else ""
    val totalW = textPaint.measureText(cachedBatteryLine)
    var drawX = centerX - totalW / 2f
    val baselineY = topY + dp(9.8f)

    if (cachedBatteryPart.isNotEmpty()) {
      textPaint.color = applyAlpha(baseInk, activeAlpha)
      canvas.drawText(cachedBatteryPart, drawX, baselineY, textPaint)
      drawX += textPaint.measureText(cachedBatteryPart)
    }

    if (sepPart.isNotEmpty()) {
      textPaint.color = applyAlpha(baseInk, (activeAlpha * 0.65f).roundToInt())
      canvas.drawText(sepPart, drawX, baselineY, textPaint)
      drawX += textPaint.measureText(sepPart)
    }

    if (cachedTempPart.isNotEmpty()) {
      val tempColor =
        when (thermalTier(telemetry.batteryTempCelsius)) {
          2 -> applyAlpha(0xFFFF7A7A.toInt(), activeAlpha)
          1 -> applyAlpha(0xFFFFD06E.toInt(), activeAlpha)
          else -> applyAlpha(baseInk, activeAlpha)
        }
      textPaint.color = tempColor
      canvas.drawText(cachedTempPart, drawX, baselineY, textPaint)
    }
  }

  private fun applyAlpha(argb: Int, alpha: Int): Int {
    return Color.argb(alpha.coerceIn(0, 255), Color.red(argb), Color.green(argb), Color.blue(argb))
  }
}
