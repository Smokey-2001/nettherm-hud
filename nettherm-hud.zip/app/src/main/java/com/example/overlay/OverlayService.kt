package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.input.InputManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.OverlayPreferencesRepository
import com.example.data.OverlayServiceState
import com.example.data.TelemetryMonitor
import com.example.model.EdgeSide
import com.example.model.OverlayConfig
import com.example.model.TelemetryFormatter
import com.example.model.TelemetrySnapshot
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class OverlayService : Service() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

  private lateinit var windowManager: WindowManager
  private lateinit var preferencesRepository: OverlayPreferencesRepository
  private lateinit var telemetryMonitor: TelemetryMonitor
  private lateinit var notificationManager: NotificationManager
  private var displayManager: DisplayManager? = null

  private var overlayView: HudOverlayView? = null
  private var layoutParams: WindowManager.LayoutParams? = null
  private var latestConfig: OverlayConfig = OverlayConfig()
  private var latestSnapshot: TelemetrySnapshot = TelemetrySnapshot()
  private var collectionJob: Job? = null

  private val displayListener =
    object : DisplayManager.DisplayListener {
      override fun onDisplayAdded(displayId: Int) = Unit

      override fun onDisplayRemoved(displayId: Int) = Unit

      override fun onDisplayChanged(displayId: Int) {
        if (displayId == Display.DEFAULT_DISPLAY) {
          updateWindowPosition(latestConfig)
        }
      }
    }

  override fun onCreate() {
    super.onCreate()
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    displayManager = getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
    preferencesRepository = OverlayPreferencesRepository(applicationContext)
    telemetryMonitor = TelemetryMonitor(applicationContext)

    ensureNotificationChannel()
    startForegroundCompat(NOTIFICATION_ID, buildNotification(isPaused = false))
    OverlayServiceState.setRunning(true)

    if (!Settings.canDrawOverlays(this)) {
      stopSelf()
      return
    }

    attachOverlayView()
    displayManager?.registerDisplayListener(displayListener, null)
    observeTelemetryAndConfig()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> {
        OverlayServiceState.setRunning(false)
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_TOGGLE_PAUSE -> {
        val nextPaused = !OverlayServiceState.isPaused.value
        OverlayServiceState.setPaused(nextPaused)
        overlayView?.visibility = if (nextPaused) View.GONE else View.VISIBLE
        notificationManager.notify(NOTIFICATION_ID, buildNotification(isPaused = nextPaused))
      }
      ACTION_SET_PAUSED -> {
        val paused = intent.getBooleanExtra(EXTRA_PAUSED, false)
        OverlayServiceState.setPaused(paused)
        overlayView?.visibility = if (paused) View.GONE else View.VISIBLE
        notificationManager.notify(NOTIFICATION_ID, buildNotification(isPaused = paused))
      }
    }
    return START_STICKY
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    updateWindowPosition(latestConfig)
  }

  override fun onDestroy() {
    super.onDestroy()
    collectionJob?.cancel()
    serviceScope.cancel()
    runCatching { displayManager?.unregisterDisplayListener(displayListener) }
    detachOverlayView()
    OverlayServiceState.setRunning(false)
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun attachOverlayView() {
    if (overlayView != null) return

    val windowType =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
      } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
      }

    // Strictly non-touchable & non-focusable so touches always pass through underneath
    val flags =
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    val params =
      WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        windowType,
        flags,
        PixelFormat.TRANSLUCENT,
      )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      params.layoutInDisplayCutoutMode =
        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      params.layoutInDisplayCutoutMode =
        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    applyPositionToParams(params, latestConfig, viewHeightPx = 0)

    val view = HudOverlayView(this)
    view.visibility = if (OverlayServiceState.isPaused.value) View.GONE else View.VISIBLE
    view.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
      val newH = bottom - top
      val oldH = oldBottom - oldTop
      if (newH != oldH && newH > 0) {
        updateWindowPosition(latestConfig)
      }
    }

    runCatching {
      windowManager.addView(view, params)
      overlayView = view
      layoutParams = params
    }.onFailure {
      stopSelf()
    }
  }

  private fun detachOverlayView() {
    val view = overlayView ?: return
    runCatching { windowManager.removeViewImmediate(view) }
    overlayView = null
    layoutParams = null
  }

  private fun observeTelemetryAndConfig() {
    collectionJob?.cancel()
    val refreshIntervalFlow = preferencesRepository.configFlow.map { it.refreshInterval }.distinctUntilChanged()
    val pauseOnScreenOffFlow = preferencesRepository.configFlow.map { it.pauseOnScreenOff }.distinctUntilChanged()

    collectionJob =
      serviceScope.launch {
        combine(
          telemetryMonitor.observeTelemetry(refreshIntervalFlow, pauseOnScreenOffFlow),
          preferencesRepository.configFlow,
          OverlayServiceState.isPaused,
        ) { snapshot, config, paused ->
          Triple(snapshot, config, paused)
        }.collect { (snapshot, config, paused) ->
          latestSnapshot = snapshot
          val layoutChanged =
            latestConfig.edgeSide != config.edgeSide ||
              latestConfig.verticalPositionPercent != config.verticalPositionPercent ||
              latestConfig.separateLandscapePos != config.separateLandscapePos ||
              latestConfig.landscapeVerticalPercent != config.landscapeVerticalPercent ||
              latestConfig.edgeMarginDp != config.edgeMarginDp ||
              latestConfig.safeOpacityCap != config.safeOpacityCap
          latestConfig = config

          val view = overlayView
          if (view != null) {
            view.visibility = if (paused) View.GONE else View.VISIBLE
            view.updateState(snapshot, config)
            if (layoutChanged) {
              updateWindowPosition(config)
            }
          }
        }
      }
  }

  private fun updateWindowPosition(config: OverlayConfig) {
    val view = overlayView ?: return
    val params = layoutParams ?: return
    val prevX = params.x
    val prevY = params.y
    val prevGravity = params.gravity
    val prevAlpha = params.alpha

    applyPositionToParams(params, config, viewHeightPx = view.height)

    if (params.x != prevX || params.y != prevY || params.gravity != prevGravity || params.alpha != prevAlpha) {
      runCatching { windowManager.updateViewLayout(view, params) }
    }
  }

  private fun applyPositionToParams(
    params: WindowManager.LayoutParams,
    config: OverlayConfig,
    viewHeightPx: Int,
  ) {
    val density = resources.displayMetrics.density
    val bounds = currentScreenBounds()
    val isLandscape = bounds.width > bounds.height

    params.gravity =
      when (config.edgeSide) {
        EdgeSide.LEFT -> Gravity.TOP or Gravity.START
        EdgeSide.RIGHT -> Gravity.TOP or Gravity.END
      }

    // Add physical display cutout inset on the chosen side so landscape camera holes never clip the HUD
    val cutoutSideInset =
      when (config.edgeSide) {
        EdgeSide.LEFT -> bounds.cutoutLeft
        EdgeSide.RIGHT -> bounds.cutoutRight
      }
    params.x = (config.edgeMarginDp * density).roundToInt().coerceAtLeast(0) + cutoutSideInset

    val effectivePercent =
      if (isLandscape && config.separateLandscapePos) {
        config.landscapeVerticalPercent.coerceIn(0.03f, 0.85f)
      } else {
        config.verticalPositionPercent.coerceIn(0.03f, 0.88f)
      }

    val safeTop = bounds.cutoutTop.coerceAtLeast((4f * density).roundToInt())
    val safeBottom = bounds.cutoutBottom.coerceAtLeast((4f * density).roundToInt())
    val maxY = (bounds.height - safeBottom - viewHeightPx.coerceAtLeast(0)).coerceAtLeast(safeTop)
    val rawY = (bounds.height * effectivePercent).roundToInt()
    params.y = rawY.coerceIn(safeTop, maxY)

    // On Android 12+ (API 31+), keeping window alpha below maximumObscuringOpacityForTouch
    // prevents Android's untrusted-touch filter from blocking taps that pass through the HUD.
    params.alpha =
      if (config.safeOpacityCap && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val inputManager = getSystemService(Context.INPUT_SERVICE) as? InputManager
        val maxSafe = inputManager?.maximumObscuringOpacityForTouch ?: 0.80f
        (maxSafe - 0.02f).coerceIn(0.50f, 0.80f)
      } else {
        1.0f
      }
  }

  private fun currentScreenBounds(): ScreenBounds {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      val metrics = windowManager.currentWindowMetrics
      val rect = metrics.bounds
      val cutout = metrics.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.displayCutout())
      return ScreenBounds(
        width = rect.width(),
        height = rect.height(),
        cutoutLeft = cutout.left,
        cutoutTop = cutout.top,
        cutoutRight = cutout.right,
        cutoutBottom = cutout.bottom,
      )
    } else {
      @Suppress("DEPRECATION")
      val dm = resources.displayMetrics
      return ScreenBounds(
        width = dm.widthPixels,
        height = dm.heightPixels,
        cutoutLeft = 0,
        cutoutTop = 0,
        cutoutRight = 0,
        cutoutBottom = 0,
      )
    }
  }

  private data class ScreenBounds(
    val width: Int,
    val height: Int,
    val cutoutLeft: Int,
    val cutoutTop: Int,
    val cutoutRight: Int,
    val cutoutBottom: Int,
  )

  private fun startForegroundCompat(id: Int, notification: Notification) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      startForeground(id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    } else {
      startForeground(id, notification)
    }
  }

  private fun ensureNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          getString(R.string.notification_channel_name),
          NotificationManager.IMPORTANCE_LOW,
        ).apply {
          description = getString(R.string.notification_channel_desc)
          setShowBadge(false)
        }
      notificationManager.createNotificationChannel(channel)
    }
  }

  private fun buildNotification(isPaused: Boolean): Notification {
    val openAppIntent =
      PendingIntent.getActivity(
        this,
        10,
        Intent(this, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val pauseIntent =
      PendingIntent.getService(
        this,
        11,
        Intent(this, OverlayService::class.java).apply { action = ACTION_TOGGLE_PAUSE },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val stopIntent =
      PendingIntent.getService(
        this,
        12,
        Intent(this, OverlayService::class.java).apply { action = ACTION_STOP },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val statusText =
      if (isPaused) {
        "Overlay paused — tap Resume to show again"
      } else {
        val tempStr =
          TelemetryFormatter.formatTemperature(
            latestSnapshot.batteryTempCelsius,
            latestConfig.tempUnit,
          )
        "Touch-through active · ${latestSnapshot.batteryPercent}% · $tempStr"
      }

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.drawable.ic_hud_notification)
      .setContentTitle(getString(R.string.notification_title))
      .setContentText(statusText)
      .setContentIntent(openAppIntent)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setSilent(true)
      .addAction(0, if (isPaused) "Resume" else "Pause", pauseIntent)
      .addAction(0, getString(R.string.action_stop_overlay), stopIntent)
      .build()
  }

  companion object {
    private const val CHANNEL_ID = "nettherm_hud_channel"
    private const val NOTIFICATION_ID = 4201
    const val ACTION_STOP = "com.example.overlay.ACTION_STOP"
    const val ACTION_TOGGLE_PAUSE = "com.example.overlay.ACTION_TOGGLE_PAUSE"
    const val ACTION_SET_PAUSED = "com.example.overlay.ACTION_SET_PAUSED"
    const val EXTRA_PAUSED = "extra_paused"

    fun start(context: Context) {
      val intent = Intent(context, OverlayService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
    }

    fun stop(context: Context) {
      val intent = Intent(context, OverlayService::class.java).apply { action = ACTION_STOP }
      if (OverlayServiceState.isRunning.value) {
        context.startService(intent)
      } else {
        context.stopService(Intent(context, OverlayService::class.java))
      }
    }

    fun setPaused(context: Context, paused: Boolean) {
      if (!OverlayServiceState.isRunning.value) return
      val intent =
        Intent(context, OverlayService::class.java).apply {
          action = ACTION_SET_PAUSED
          putExtra(EXTRA_PAUSED, paused)
        }
      context.startService(intent)
    }
  }
}
