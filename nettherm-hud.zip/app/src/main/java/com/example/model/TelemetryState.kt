package com.example.model

import android.net.wifi.ScanResult
import android.os.Build
import java.util.Locale
import kotlin.math.roundToInt

enum class EdgeSide {
  LEFT,
  RIGHT,
}

enum class TempUnit {
  CELSIUS,
  FAHRENHEIT,
}

enum class RefreshInterval(val label: String, val intervalMs: Long) {
  LIVE_1S("1s Live", 1000L),
  BALANCED_2S("2s Eco", 2000L),
  ULTRA_3S("3s Ultra", 3000L),
}

enum class InkPreset(val label: String, val argb: Int) {
  CRISP_WHITE("Crisp White", 0xFFFFFFFF.toInt()),
  WARM_IVORY("Warm Ivory", 0xFFF5EFE0.toInt()),
  OBSIDIAN_INK("Obsidian Ink", 0xFF141619.toInt()),
  CYAN_HUD("Cyan HUD", 0xFF7CE8FF.toInt()),
  AMBER_HUD("Warm Amber", 0xFFFFD17A.toInt()),
}

data class TelemetrySnapshot(
  val isWifiConnected: Boolean = false,
  val wifiSignalLevel: Int = 0, // 0..4
  val wifiRssiDbm: Int = -127,
  val wifiVersionLabel: String = "–",
  val wifiStandardDescription: String = "Disconnected",
  val wifiLinkSpeedMbps: Int = 0,
  val wifiFrequencyMhz: Int = 0,
  val rxBytesPerSec: Long = 0L,
  val txBytesPerSec: Long = 0L,
  val totalBytesPerSec: Long = 0L,
  val batteryPercent: Int = 0,
  val batteryTempCelsius: Float = 0f,
  val batteryStatusLabel: String = "Unknown",
  val batteryVoltageMv: Int = 0,
)

data class OverlayConfig(
  val edgeSide: EdgeSide = EdgeSide.RIGHT,
  val verticalPositionPercent: Float = 0.18f,
  val separateLandscapePos: Boolean = true,
  val landscapeVerticalPercent: Float = 0.10f,
  val edgeMarginDp: Float = 6f,
  val scale: Float = 1.0f,
  val contentAlpha: Float = 0.78f,
  val backdropAlpha: Float = 0.0f,
  val safeOpacityCap: Boolean = true,
  val refreshInterval: RefreshInterval = RefreshInterval.BALANCED_2S,
  val pauseOnScreenOff: Boolean = true,
  val inkPreset: InkPreset = InkPreset.CRISP_WHITE,
  val tempUnit: TempUnit = TempUnit.CELSIUS,
  val showSpeed: Boolean = true,
  val showWifiSignal: Boolean = true,
  val showWifiVersion: Boolean = true,
  val showBatteryPercent: Boolean = true,
  val showBatteryTemp: Boolean = true,
)

object TelemetryFormatter {

  fun formatSpeedStacked(bytesPerSec: Long): Pair<String, String> {
    val safeBytes = bytesPerSec.coerceAtLeast(0L)
    return when {
      safeBytes < 1024L -> {
        val kb = safeBytes / 1024.0
        if (safeBytes == 0L) {
          "0.00" to "KB/S"
        } else {
          String.format(Locale.US, "%.2f", kb) to "KB/S"
        }
      }
      safeBytes < 1024L * 1024L -> {
        val kb = safeBytes / 1024.0
        val value =
          if (kb >= 100.0) {
            String.format(Locale.US, "%.1f", kb)
          } else {
            String.format(Locale.US, "%.2f", kb)
          }
        value to "KB/S"
      }
      safeBytes < 1024L * 1024L * 1024L -> {
        val mb = safeBytes / (1024.0 * 1024.0)
        val value =
          if (mb >= 100.0) {
            String.format(Locale.US, "%.1f", mb)
          } else {
            String.format(Locale.US, "%.2f", mb)
          }
        value to "MB/S"
      }
      else -> {
        val gb = safeBytes / (1024.0 * 1024.0 * 1024.0)
        String.format(Locale.US, "%.2f", gb) to "GB/S"
      }
    }
  }

  fun formatSpeedInline(bytesPerSec: Long): String {
    val (value, unit) = formatSpeedStacked(bytesPerSec)
    return "$value $unit"
  }

  fun formatTemperature(tempCelsius: Float, unit: TempUnit): String {
    return when (unit) {
      TempUnit.CELSIUS -> String.format(Locale.US, "%.1f°C", tempCelsius)
      TempUnit.FAHRENHEIT -> {
        val fahrenheit = (tempCelsius * 9f / 5f) + 32f
        String.format(Locale.US, "%.1f°F", fahrenheit)
      }
    }
  }

  fun thermalCategoryLabel(tempCelsius: Float): String {
    return when {
      tempCelsius <= 0f -> "Unavailable"
      tempCelsius < 35f -> "Cool"
      tempCelsius < 39.5f -> "Normal"
      tempCelsius < 43f -> "Warm"
      else -> "Hot"
    }
  }

  fun normalizeSignalLevel(rawLevel: Int, maxLevel: Int): Int {
    if (maxLevel <= 0) return 0
    val scaled = ((rawLevel.coerceIn(0, maxLevel).toFloat() / maxLevel.toFloat()) * 4f).roundToInt()
    return scaled.coerceIn(0, 4)
  }

  fun resolveWifiVersion(
    wifiStandard: Int?,
    frequencyMhz: Int,
    linkSpeedMbps: Int,
    isConnected: Boolean,
  ): Pair<String, String> {
    if (!isConnected) return "–" to "Disconnected"

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && wifiStandard != null) {
      when (wifiStandard) {
        ScanResult.WIFI_STANDARD_11BE -> return "7" to "Wi-Fi 7 (802.11be)"
        ScanResult.WIFI_STANDARD_11AX -> {
          return if (frequencyMhz >= 5925) {
            "6E" to "Wi-Fi 6E (6 GHz)"
          } else {
            "6" to "Wi-Fi 6 (802.11ax)"
          }
        }
        ScanResult.WIFI_STANDARD_11AC -> return "5" to "Wi-Fi 5 (802.11ac)"
        ScanResult.WIFI_STANDARD_11N -> return "4" to "Wi-Fi 4 (802.11n)"
        ScanResult.WIFI_STANDARD_LEGACY -> return "3" to "Legacy Wi-Fi (802.11a/b/g)"
      }
    }

    // Fallback heuristic for older Android versions (< API 30) or unknown standard
    return when {
      frequencyMhz >= 5925 -> "6E" to "6 GHz Wi-Fi"
      frequencyMhz >= 4900 && linkSpeedMbps >= 150 -> "5" to "Wi-Fi 5 (5 GHz)"
      frequencyMhz in 2400..2500 -> "4" to "Wi-Fi 4 (2.4 GHz)"
      linkSpeedMbps > 54 -> "4" to "Wi-Fi 4+"
      else -> "4" to "Wi-Fi Connected"
    }
  }
}
